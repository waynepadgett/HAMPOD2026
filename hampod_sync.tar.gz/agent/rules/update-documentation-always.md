---
trigger: always_on
---

Always update the documentation every time you do a commit.