#usr/bin/bash
unlink Firmware_i
unlink Firmware_o
unlink Keypad_i
unlink Keypad_o
unlink Speaker_i
unlink Speaker_o
unlink Serial_i
unlink Serial_o
