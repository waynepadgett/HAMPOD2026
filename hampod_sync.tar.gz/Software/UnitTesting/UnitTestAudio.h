#ifndef HAMPOD_TESTING_AUDIO
#define HAMPOD_TESTING_AUDIO

#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include "../GeneralFunctions.h"
#include "../FirmwareCommunication.h"
bool testCreatingAudioHash();
bool testGetAudio();

#include "UnitTestAudio.c"
#endif