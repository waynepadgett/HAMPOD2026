#ifndef HAMPOD_TESTING_READFILE
#define HAMPOD_TESTING_READFILE
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include "../GeneralFunctions.h"

bool testReadingFile();

#include "UnitTestReadFile.c"
#endif