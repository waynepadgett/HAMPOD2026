#ifndef HAMPOD_TESTING_RADIO
#define HAMPOD_TESTING_RADIO

//TODO make the approperate connected file for this
bool testloadUpRadioUsingData();
bool testgetCurrentMode();
bool testgetModeDetails();
bool testsetRadioMode();
bool testgetRadioDetailsInSavableFormat();
#endif